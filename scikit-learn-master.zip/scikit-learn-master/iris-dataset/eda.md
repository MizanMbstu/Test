# এক্সপ্লোরেটোরি ডাটা অ্যানালাইসিস

নিচের লিংকে ক্লিক করুন। 

{% embed url="https://github.com/raqueeb/ml-python/blob/master/exploratory-data-analysis.ipynb" %}

অথবা, এখানে 

{% embed url="https://nbviewer.jupyter.org/github/raqueeb/ml-python/blob/master/exploratory-data-analysis.ipynb" %}

