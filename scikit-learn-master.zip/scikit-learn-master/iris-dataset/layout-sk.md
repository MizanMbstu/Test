# সাইকিট-লার্ন এর ডাটা লে-আউট, ডাটা হ্যান্ডলিং

> With data collection, ‘the sooner the better’ is always the best answer. 
>
> – Marissa Mayer

এই অংশটুকু পুরোটাই লিখেছি জুপিটার নোটবুকে। আপনাদের সুবিধার্থে। গিটহাবে জুপিটার নোটবুক রেন্ডার করলেও তাদের টাইমআউট ভ্যালু বেশ কম। সেকারণে এনবি-ভিউয়ার খারাপ নয়। দুটোরই লিংক দিলাম, যার যেটা পছন্দ। 

গিটহাব লিংক: 

{% embed url="https://github.com/raqueeb/ml-python/blob/master/test-scikit-learn.ipynb" %}

এনবি ভিউয়ার লিংক: 

{% embed url="http://nbviewer.jupyter.org/github/raqueeb/ml-python/blob/master/test-scikit-learn.ipynb" %}

