# ট্রেনিং ডেটার ওপর ইভ্যালুয়েশন

নিচের লিংক ক্লিক করে পড়ুন, লেখা হয়েছে জুপিটার নোটবুকে। 

{% embed url="https://github.com/raqueeb/ml-python/blob/master/model-evaluation1.ipynb" %}

অথবা, আগেরটা কাজ না করলে নিচের লিংক 

{% embed url="https://nbviewer.jupyter.org/github/raqueeb/ml-python/blob/master/model-evaluation1.ipynb" %}

