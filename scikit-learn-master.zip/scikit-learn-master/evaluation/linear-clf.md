# ছোট্ট একটা লিনিয়ার ক্লাসিফিকেশন

{% embed url="https://github.com/raqueeb/ml-python/blob/master/linear-clf-final.ipynb" %}



