# ডিসিশন ট্রি কিভাবে কাজ করে? খালি চোখে আইরিস ডেটাসেট

গিটহাবের লিংক

[https://github.com/raqueeb/ml-python/blob/master/colab/decision\_tree.ipynb](https://github.com/raqueeb/ml-python/blob/master/colab/decision_tree.ipynb)

গুগল কোলাবের লিংক

[https://colab.research.google.com/github/raqueeb/ml-python/blob/master/colab/decision\_tree.ipynb](https://colab.research.google.com/github/raqueeb/ml-python/blob/master/colab/decision_tree.ipynb)

