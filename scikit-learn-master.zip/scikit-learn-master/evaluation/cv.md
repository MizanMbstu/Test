# ক্রস ভ্যালিডেশনের প্যারামিটারের টিউনিং, মডেল সিলেকশন

ক্লিক করুন নিচের যেকোন একটা লিংকে 

{% embed url="https://github.com/raqueeb/ml-python/blob/master/cross-validation.ipynb" %}

{% embed url="https://nbviewer.jupyter.org/github/raqueeb/ml-python/blob/master/cross-validation.ipynb" %}

